package org.iesalixar.services;

import java.util.List;

import org.iesalixar.model.Asignatura;

public interface AsignaturaService {

	public List<Asignatura> getAllAsignatura();
}
