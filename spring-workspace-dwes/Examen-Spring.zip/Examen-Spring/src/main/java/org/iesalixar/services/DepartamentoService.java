package org.iesalixar.services;

import java.util.List;

import org.iesalixar.model.Departamento;

public interface DepartamentoService {
	
	public List<Departamento> getAllDepartments();
}