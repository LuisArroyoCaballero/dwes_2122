package Classes;

public class Pared {
	private double altura;
	public Pared(double altura) {
		this.altura=altura;
	}
	
	//TO STRING
	
	@Override
	public String toString() {
		return "Pared [altura=" + altura + "]";
	}
	
	
	
}
