package Classes;

public class Tejado {
	public Tejado() {
	}
	
	public void darSoporte() {
		System.out.println("Paro la lluvia");
	}
	
}
