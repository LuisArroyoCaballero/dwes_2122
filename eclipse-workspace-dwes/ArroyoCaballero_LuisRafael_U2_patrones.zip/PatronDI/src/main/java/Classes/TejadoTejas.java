package Classes;

public class TejadoTejas extends Tejado{

	public TejadoTejas() {
	}

	@Override
	public void darSoporte() {
		System.out.println("Paro la lluvia y no tengo goteras");
	}
	
	//TO STRING
	
	
	
	
	
}
