package Factory;

public enum EnumFigura {
	Triangulo,
	Circulo,
	Cuadrado,
	Rectangulo;
}
